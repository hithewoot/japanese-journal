// Frontend: só conversa com a API (/api). Para adicionar uma área, inclua-a em TYPES e na API.
const TYPES = {
  notes: { label: 'Anotações', main: 'title', sub: 'content', fields: [['title', 'Título', 'text'], ['content', 'Conteúdo', 'area'], ['category_id', 'Categoria', 'cat'], ['level', 'Nível', 'text'], ['source', 'Fonte (aula, livro, anime...)', 'text'], ['personal_note', 'Observações pessoais', 'area'], ['tags', 'Tags (separadas por vírgula)', 'text']] },
  vocabulary: { label: 'Vocabulário', main: 'word', sub: 'meaning', fields: [['word', 'Palavra', 'text'], ['reading', 'Leitura', 'text'], ['romaji', 'Romaji', 'text'], ['meaning', 'Significado', 'text'], ['part_of_speech', 'Classe gramatical', 'text'], ['example', 'Frase de exemplo', 'text'], ['example_translation', 'Tradução', 'text'], ['notes', 'Observações', 'area'], ['level', 'Dificuldade', 'text'], ['tags', 'Tags', 'text']] },
  kanji: { label: 'Kanji', main: 'kanji', sub: 'meaning', fields: [['kanji', 'Kanji', 'text'], ['meaning', 'Significado', 'text'], ['onyomi', 'Onyomi', 'text'], ['kunyomi', 'Kunyomi', 'text'], ['compounds', 'Palavras compostas', 'area'], ['examples', 'Frases de exemplo', 'area'], ['radicals', 'Componentes/radicais', 'text'], ['notes', 'Observações', 'area'], ['jlpt', 'JLPT', 'text'], ['tags', 'Tags', 'text']] },
  grammar: { label: 'Gramática', main: 'title', sub: 'explanation', fields: [['title', 'Estrutura', 'text'], ['explanation', 'Explicação', 'area'], ['formation', 'Formação', 'text'], ['usage', 'Quando usar', 'area'], ['examples', 'Exemplos', 'area'], ['comparisons', 'Comparações', 'area'], ['common_mistakes', 'Erros comuns', 'area'], ['notes', 'Observações', 'area'], ['level', 'Dificuldade', 'text'], ['tags', 'Tags', 'text']] },
  phrases: { label: 'Frases', main: 'phrase', sub: 'translation', fields: [['phrase', 'Frase', 'text'], ['reading', 'Leitura', 'text'], ['romaji', 'Romaji', 'text'], ['translation', 'Tradução', 'text'], ['context', 'Contexto', 'area'], ['explanation', 'Explicação', 'area'], ['source', 'Fonte', 'text'], ['tags', 'Tags', 'text']] },
};
const PAGES = [['home', 'Início'], ...Object.entries(TYPES).map(([k, v]) => [k, v.label]), ['review', 'Revisão'], ['favorites', 'Favoritos'], ['calendar', 'Calendário'], ['settings', 'Config.']];
const $ = (s) => document.querySelector(s), main = $('#main');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const toast = (m) => { const t = $('#toast'); t.textContent = m; t.className = 'show'; setTimeout(() => (t.className = ''), 2500); };
async function api(path, method = 'GET', body) {
  const r = await fetch('/api/' + path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Erro'); return j;
}
const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast('Erro: ' + e.message); } };
let cats = [], filters = { q: '', sort: 'updated', view: 'list' };

function applySettings(s) {
  document.documentElement.dataset.theme = s.theme || 'light';
  if (s.accent) document.documentElement.style.setProperty('--accent', s.accent);
}
function nav(cur) {
  $('#nav').innerHTML = '<h1>日本語 <span>Journal</span></h1>' + PAGES.map(([k, l]) => `<button data-p="${k}" class="${k === cur ? 'on' : ''}">${l}</button>`).join('');
  $('#nav').onclick = (e) => e.target.dataset.p && go(e.target.dataset.p);
}
async function go(page) {
  nav(page); main.innerHTML = '<p class="muted">Carregando…</p>';
  try { await PAGE[page] ? PAGE[page](page) : PAGE.list(page); } catch (e) { main.innerHTML = `<p>Erro: ${esc(e.message)} <button class="btn" onclick="go('${page}')">Tentar de novo</button></p>`; }
}
const itemCard = (it) => {
  const T = TYPES[it._type];
  return `<div class="card"><div class="row"><div class="grow"><b>${esc(it._title)}</b> <span class="muted">${T.label}</span><div class="muted">${esc(String(it[T.sub] || '').slice(0, 140))}</div>
  ${it.tags ? it.tags.split(',').map((t) => `<span class="tag">${esc(t.trim())}</span>`).join(' ') : ''}</div>
  <button class="ic ${it.favorite ? 'on' : ''}" title="Favoritar" data-a="fav" data-t="${it._type}" data-id="${it.id}">★</button>
  <button class="ic ${it.review_flag ? 'on' : ''}" title="Marcar para revisão" data-a="rev" data-t="${it._type}" data-id="${it.id}">⚑</button>
  <button class="ic" title="Editar" data-a="edit" data-t="${it._type}" data-id="${it.id}">✎</button>
  <button class="ic" title="Excluir" data-a="del" data-t="${it._type}" data-id="${it.id}">🗑</button></div></div>`;
};
// Ações dos cartões (favoritar, revisar, editar, excluir) por delegação de eventos.
main.addEventListener('click', guard(async (e) => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const { a, t, id } = b.dataset;
  if (a === 'fav') { await api(`${t}/${id}/favorite`, 'POST'); }
  if (a === 'rev') { const cur = b.classList.contains('on'); await api(`${t}/${id}`, 'PUT', { review_flag: !cur }); }
  if (a === 'edit') return openForm(t, await api(`${t}/${id}`));
  if (a === 'del') { if (!confirm('Excluir este item? Isso não pode ser desfeito.')) return; await api(`${t}/${id}`, 'DELETE'); toast('Excluído'); }
  go(document.querySelector('nav .on').dataset.p);
}));

function openForm(type, item = {}) {
  const T = TYPES[type], dlg = document.createElement('dialog');
  dlg.innerHTML = `<form method="dialog"><h3>${item.id ? 'Editar' : 'Novo'} — ${T.label}</h3>` + T.fields.map(([k, l, kind]) => `<label for="f_${k}">${l}</label>` + (kind === 'area' ? `<textarea id="f_${k}" rows="4">${esc(item[k])}</textarea>` : kind === 'cat' ? `<select id="f_${k}"><option value="">—</option>${cats.map((c) => `<option value="${c.id}" ${item[k] == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>` : `<input id="f_${k}" value="${esc(item[k])}">`)).join('') +
    `<div class="row" style="margin-top:14px"><button class="btn" value="save">Salvar</button><button class="btn ghost" value="cancel">Cancelar</button></div></form>`;
  document.body.append(dlg); dlg.showModal();
  dlg.addEventListener('close', guard(async () => {
    if (dlg.returnValue === 'save') {
      const body = {}; T.fields.forEach(([k]) => (body[k] = $(`#f_${k}`).value || null));
      if (body.category_id) body.category_id = +body.category_id;
      await api(item.id ? `${type}/${item.id}` : type, item.id ? 'PUT' : 'POST', body); toast('Salvo!');
      go(document.querySelector('nav .on').dataset.p);
    }
    dlg.remove();
  }));
}
// Atalho: "n" abre uma nova anotação.
document.addEventListener('keydown', (e) => { if (e.key === 'n' && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) && !document.querySelector('dialog')) openForm('notes'); });

const PAGE = {
  async home() {
    const s = await api('stats'), set = await api('settings'), due = (await api('review')).due.length;
    const pct = s.total ? Math.round((100 * s.known) / s.total) : 0;
    main.innerHTML = `<h2>おかえりなさい！ ${esc(set.name || '')}</h2><p class="muted">${new Date().toLocaleDateString('pt-BR', { dateStyle: 'full' })}</p>
    <div class="card">「継続は力なり」 — <span class="muted">Persistência é poder.</span></div>
    <button class="btn" onclick="openForm('notes')">+ Nova anotação</button>
    <div class="stats" style="margin-top:14px">${Object.entries(s.counts).map(([k, n]) => `<div class="card"><b>${n}</b>${TYPES[k].label}</div>`).join('')}</div>
    <div class="card">Progresso: ${s.known} de ${s.total} itens marcados como “já sei” (${pct}%)<div class="bar"><i style="width:${pct}%"></i></div></div>
    <h3>Continue estudando</h3>${due ? `<button class="btn" onclick="go('review')">${due} para revisar agora</button>` : '<p class="muted">Nada pendente por enquanto.</p>'}
    <h3>Anotações recentes</h3>${s.recent.map(itemCard).join('') || '<p class="muted">Nada ainda. Clique em “Nova anotação” para começar.</p>'}`;
  },
  async list(type) {
    const T = TYPES[type]; cats = await api('categories');
    const rows = await api(`${type}?q=${encodeURIComponent(filters.q)}&sort=${filters.sort}`);
    main.innerHTML = `<h2>${T.label}</h2><div class="row"><input class="grow" id="q" placeholder="Pesquisar…" aria-label="Pesquisar" value="${esc(filters.q)}">
    <select id="sort" aria-label="Ordenar" style="width:auto"><option value="updated">Atualização</option><option value="created">Criação</option><option value="title">Título</option></select>
    <button class="btn ghost" id="clear">Limpar</button><button class="btn" id="new">+ Novo</button></div>
    ${rows.length ? rows.map((r) => itemCard({ ...r, _type: type, _title: r[T.main] })).join('') : `<p class="muted">${filters.q ? 'Nenhum resultado.' : 'Nada registrado ainda. Clique em “+ Novo”.'}</p>`}`;
    $('#sort').value = filters.sort;
    $('#q').onchange = (e) => { filters.q = e.target.value; go(type); };
    $('#sort').onchange = (e) => { filters.sort = e.target.value; go(type); };
    $('#clear').onclick = () => { filters.q = ''; filters.sort = 'updated'; go(type); };
    $('#new').onclick = () => openForm(type);
  },
  async favorites() {
    const rows = await api('favorites');
    main.innerHTML = `<h2>Favoritos</h2>${rows.map(itemCard).join('') || '<p class="muted">Use ★ para favoritar itens.</p>'}`;
  },
  async review() {
    const { due, history } = await api('review');
    main.innerHTML = `<h2>Revisão</h2>${due.length ? `<div class="card" id="rc"></div>` : '<p class="muted">Nada pendente. Marque itens com ⚑ para revisá-los.</p>'}
    <h3>Histórico recente</h3>${history.map((h) => `<div class="muted">${h.reviewed_at.slice(0, 10)} · ${h.item_type} #${h.item_id} · ${h.result} · próxima: ${h.next_review.slice(0, 10)} ${esc(h.note || '')}</div>`).join('') || '<p class="muted">Sem revisões ainda.</p>'}`;
    if (!due.length) return;
    let i = 0;
    const show = () => {
      if (i >= due.length) { go('review'); return; }
      const it = due[i], T = TYPES[it._type];
      $('#rc').innerHTML = `<div class="muted">${i + 1}/${due.length} · ${T.label}</div><div class="big">${esc(it._title)}</div>
      <details><summary>Mostrar resposta</summary><p>${esc(it[T.sub])}</p><p class="muted">${esc(it.reading || it.example || '')}</p></details>
      <label for="rn">Observação (opcional)</label><input id="rn"><div class="row" style="margin-top:12px">
      ${[['unknown', 'Ainda não sei'], ['learning', 'Estou aprendendo'], ['known', 'Já sei']].map(([r, l]) => `<button class="btn ${r === 'known' ? '' : 'ghost'}" data-r="${r}">${l}</button>`).join('')}</div>`;
      $('#rc').onclick = guard(async (e) => {
        const r = e.target.dataset.r; if (!r) return;
        await api(`${it._type}/${it.id}/review`, 'POST', { result: r, note: $('#rn').value }); // só avança se salvou
        toast('Revisão salva'); i++; show();
      });
    };
    show();
  },
  async calendar() {
    const month = (filters.month ||= new Date().toISOString().slice(0, 7)), [y, m] = month.split('-').map(Number);
    const act = await api('calendar?month=' + month), days = new Date(y, m, 0).getDate(), first = new Date(y, m - 1, 1).getDay();
    const shift = (d) => { const x = new Date(y, m - 1 + d, 1); filters.month = `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}`; go('calendar'); };
    main.innerHTML = `<h2>Calendário</h2><div class="row"><button class="btn ghost" id="pv">←</button><b class="grow" style="text-align:center">${month}</b><button class="btn ghost" id="nx">→</button></div>
    <div class="cal" style="margin-top:10px">${'<span></span>'.repeat(first)}${Array.from({ length: days }, (_, k) => { const d = `${month}-${String(k + 1).padStart(2, '0')}`; return `<button data-d="${d}" class="${act[d] ? 'act' : ''}" title="${act[d] || 0} registros">${k + 1}${act[d] ? `<br><small>${act[d]}</small>` : ''}</button>`; }).join('')}</div>
    <p class="muted">${Object.keys(act).length} dias com atividade neste mês. Dias de descanso também fazem parte do estudo.</p><div id="day"></div>`;
    $('#pv').onclick = () => shift(-1); $('#nx').onclick = () => shift(1);
    $('.cal').onclick = guard(async (e) => { const d = e.target.closest('[data-d]')?.dataset.d; if (d) $('#day').innerHTML = `<h3>${d}</h3>` + ((await api('day?date=' + d)).map(itemCard).join('') || '<p class="muted">Sem anotações criadas neste dia.</p>'); });
  },
  async settings() {
    const s = await api('settings'); cats = await api('categories');
    main.innerHTML = `<h2>Configurações</h2><label for="sn">Nome</label><input id="sn" value="${esc(s.name)}">
    <label for="st">Tema</label><select id="st"><option value="light">Claro</option><option value="dark">Escuro</option></select>
    <label for="sa">Cor de destaque</label><input id="sa" type="color" value="${s.accent || '#C98F9B'}">
    <div class="row" style="margin-top:12px"><button class="btn" id="ss">Salvar</button></div>
    <h3>Categorias</h3>${cats.map((c) => `<span class="tag" style="border-left:4px solid ${c.color}">${esc(c.name)}</span> `).join('')}
    <div class="row" style="margin-top:8px"><input id="cn" class="grow" placeholder="Nova categoria"><input id="cc" type="color" value="#8FA998" style="width:50px"><button class="btn ghost" id="ca">Adicionar</button></div>
    <h3>Dados</h3><div class="row"><a class="btn ghost" href="/api/export" download="japanese-journal.json">Exportar JSON</a><input type="file" id="imp" accept=".json" style="width:auto"></div>
    <p class="muted">Importar substitui os dados atuais (um backup automático é salvo em backups/ antes). Versão 0.1.0.</p>`;
    $('#st').value = s.theme || 'light';
    $('#ss').onclick = guard(async () => { applySettings(await api('settings', 'PUT', { name: $('#sn').value, theme: $('#st').value, accent: $('#sa').value })); toast('Salvo!'); });
    $('#ca').onclick = guard(async () => { await api('categories', 'POST', { name: $('#cn').value, color: $('#cc').value }); go('settings'); });
    $('#imp').onchange = guard(async (e) => { if (!confirm('Substituir todos os dados atuais?')) return; const r = await api('import', 'POST', JSON.parse(await e.target.files[0].text())); toast('Importado. Backup: ' + r.safety_backup); });
  },
};
api('settings').then(applySettings).catch(() => {}); go('home');
