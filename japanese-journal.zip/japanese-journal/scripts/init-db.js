import { openDb, DB_PATH } from '../src/db.js';
const db = openDb(); db.close();
console.log('Banco pronto em', DB_PATH);
