// Gera backups/japanese_journal-AAAA-MM-DD_HHMMSS.db. Restaurar: pare o servidor e copie o arquivo sobre database/japanese_journal.db.
import { openDb } from '../src/db.js';
import path from 'node:path';
import { ROOT } from '../src/db.js';
const db = openDb();
const stamp = new Date().toISOString().replace(/[:T]/g, (c) => (c === 'T' ? '_' : '')).slice(0, 17);
const dest = path.join(ROOT, 'backups', `japanese_journal-${stamp}.db`);
await db.backup(dest);
console.log('Backup criado:', dest);
