import test from 'node:test';
import assert from 'node:assert';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.DB_PATH = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'jj-')), 't.db');
const { openDb } = await import('../src/db.js');
const { nextStep, calculateNextReview } = await import('../src/srs.js');
test('banco inicializa e seed não duplica', () => {
  const a = openDb(); const n = a.prepare('SELECT COUNT(*) n FROM categories').get().n; a.close();
  const b = openDb(); assert.equal(b.prepare('SELECT COUNT(*) n FROM categories').get().n, n); assert.equal(n, 14);
});
test('japonês é preservado', () => {
  const db = openDb(); const ts = new Date().toISOString();
  db.prepare('INSERT INTO kanji (kanji,meaning,created_at,updated_at) VALUES (?,?,?,?)').run('日本語', 'língua', ts, ts);
  assert.equal(db.prepare('SELECT kanji FROM kanji WHERE kanji LIKE ?').get('%本%').kanji, '日本語');
});
test('revisão espaçada', () => {
  assert.equal(nextStep(2, 'known'), 3); assert.equal(nextStep(2, 'unknown'), 0); assert.equal(nextStep(2, 'learning'), 2);
  assert.equal(calculateNextReview('2026-01-01T00:00:00.000Z', 0).slice(0, 10), '2026-01-02');
});
