// API REST + arquivos estáticos (só public/). O .db nunca é servido.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { openDb, ROOT } from './src/db.js';
import { RESULTS, nextStep, calculateNextReview } from './src/srs.js';

// Para adicionar uma nova área: crie a tabela numa migração, registre-a aqui e em public/app.js.
export const CONTENT = {
  notes: ['title', 'content', 'category_id', 'level', 'source', 'personal_note', 'tags'],
  vocabulary: ['word', 'reading', 'romaji', 'meaning', 'part_of_speech', 'example', 'example_translation', 'notes', 'level', 'tags'],
  kanji: ['kanji', 'meaning', 'onyomi', 'kunyomi', 'compounds', 'examples', 'radicals', 'notes', 'jlpt', 'tags'],
  grammar: ['title', 'explanation', 'formation', 'usage', 'examples', 'comparisons', 'common_mistakes', 'notes', 'level', 'tags'],
  phrases: ['phrase', 'reading', 'romaji', 'translation', 'context', 'explanation', 'source', 'tags'],
};
const COMMON = ['favorite', 'review_flag', 'mastery'];
const now = () => new Date().toISOString();
const db = openDb();

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const mainCol = (t) => CONTENT[t][0];
const table = (t) => { if (!CONTENT[t]) throw new HttpError(404, 'Área desconhecida'); return t; };

// Só colunas permitidas passam (evita SQL arbitrário/colunas inesperadas).
function pick(t, body) {
  const o = {};
  for (const c of [...CONTENT[t], ...COMMON]) if (body[c] !== undefined) o[c] = typeof body[c] === 'boolean' ? +body[c] : body[c];
  if (o.mastery && !RESULTS.includes(o.mastery)) throw new HttpError(400, 'Domínio inválido');
  return o;
}
function create(t, body) {
  const d = pick(t, body);
  if (!String(d[mainCol(t)] ?? '').trim()) throw new HttpError(400, 'O campo principal é obrigatório');
  const ts = now();
  const cols = [...Object.keys(d), 'created_at', 'updated_at'];
  const r = db.prepare(`INSERT INTO ${t} (${cols}) VALUES (${cols.map(() => '?')})`).run(...Object.values(d), ts, ts);
  return db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(r.lastInsertRowid);
}
function update(t, id, body) {
  const d = pick(t, body);
  if (d[mainCol(t)] !== undefined && !String(d[mainCol(t)]).trim()) throw new HttpError(400, 'O campo principal é obrigatório');
  const cols = [...Object.keys(d), 'updated_at'];
  const r = db.prepare(`UPDATE ${t} SET ${cols.map((c) => c + '=?')} WHERE id=?`).run(...Object.values(d), now(), id);
  if (!r.changes) throw new HttpError(404, 'Registro não encontrado');
  return db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(id);
}
function list(t, q) {
  const where = [], args = [];
  if (q.q) { where.push('(' + CONTENT[t].map((c) => `${c} LIKE ?`).join(' OR ') + ')'); CONTENT[t].forEach(() => args.push(`%${q.q}%`)); }
  if (q.favorite) where.push('favorite=1');
  if (q.review) where.push('review_flag=1');
  if (q.category_id && t === 'notes') { where.push('category_id=?'); args.push(q.category_id); }
  const order = { title: `${mainCol(t)} COLLATE NOCASE`, created: 'created_at DESC' }[q.sort] || 'updated_at DESC';
  return db.prepare(`SELECT * FROM ${t} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}`).all(...args);
}
const tag = (t, rows) => rows.map((r) => ({ ...r, _type: t, _title: r[mainCol(t)] }));
const allItems = (fn) => Object.keys(CONTENT).flatMap((t) => tag(t, fn(t)));

function review(t, id, { result, note }) {
  if (!RESULTS.includes(result)) throw new HttpError(400, 'Resultado inválido');
  const item = db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(id);
  if (!item) throw new HttpError(404, 'Registro não encontrado');
  const step = nextStep(item.review_step, result), ts = now(), next = calculateNextReview(ts, step);
  // Transação: ou salva tudo, ou nada.
  db.transaction(() => {
    db.prepare(`UPDATE ${t} SET review_step=?, mastery=?, last_review=?, next_review=?, updated_at=? WHERE id=?`).run(step, result, ts, next, ts, id);
    db.prepare('INSERT INTO review_history (item_type,item_id,result,note,reviewed_at,next_review) VALUES (?,?,?,?,?,?)').run(t, id, result, note || null, ts, next);
  })();
  return { next_review: next, step };
}

function exportAll() {
  const out = { app: 'japanese-journal', version: 1, exported_at: now(), tables: { categories: db.prepare('SELECT * FROM categories').all(), review_history: db.prepare('SELECT * FROM review_history').all() } };
  for (const t of Object.keys(CONTENT)) out.tables[t] = db.prepare(`SELECT * FROM ${t}`).all();
  return out;
}
// Importação: valida, faz backup automático e substitui tudo dentro de uma transação.
async function importAll(data) {
  const names = ['categories', ...Object.keys(CONTENT), 'review_history'];
  if (data?.app !== 'japanese-journal' || !data.tables || names.some((n) => !Array.isArray(data.tables[n]))) throw new HttpError(400, 'Arquivo de backup inválido');
  const dest = path.join(ROOT, 'backups', `pre-import-${now().replace(/[:.]/g, '-')}.db`);
  await db.backup(dest);
  db.transaction(() => {
    for (const n of [...names].reverse()) db.exec(`DELETE FROM ${n}`);
    for (const n of names) {
      const valid = new Set(db.prepare(`PRAGMA table_info(${n})`).all().map((c) => c.name));
      for (const row of data.tables[n]) {
        const cols = Object.keys(row).filter((c) => valid.has(c));
        db.prepare(`INSERT INTO ${n} (${cols}) VALUES (${cols.map(() => '?')})`).run(...cols.map((c) => row[c]));
      }
    }
  })();
  return { ok: true, safety_backup: path.basename(dest) };
}

// Atividade por dia = anotações criadas + revisões feitas (dados reais).
function activityByDay(month) {
  const parts = [...Object.keys(CONTENT).map((t) => `SELECT substr(created_at,1,10) d FROM ${t}`), 'SELECT substr(reviewed_at,1,10) d FROM review_history'];
  const rows = db.prepare(`SELECT d, COUNT(*) n FROM (${parts.join(' UNION ALL ')}) WHERE d LIKE ? GROUP BY d`).all(`${month}%`);
  return Object.fromEntries(rows.map((r) => [r.d, r.n]));
}

async function route(req, url, body) {
  const p = url.pathname.split('/').filter(Boolean).slice(1), q = Object.fromEntries(url.searchParams), m = req.method;
  const [a, b, c] = p;
  if (a === 'stats') {
    const counts = Object.fromEntries(Object.keys(CONTENT).map((t) => [t, db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n]));
    const total = Object.values(counts).reduce((x, y) => x + y, 0);
    const known = Object.keys(CONTENT).reduce((s, t) => s + db.prepare(`SELECT COUNT(*) n FROM ${t} WHERE mastery='known'`).get().n, 0);
    const recent = allItems((t) => db.prepare(`SELECT * FROM ${t} ORDER BY updated_at DESC LIMIT 5`).all()).sort((x, y) => y.updated_at.localeCompare(x.updated_at)).slice(0, 6);
    return { counts, total, known, recent };
  }
  if (a === 'search') return allItems((t) => (q.q ? list(t, { q: q.q }) : []));
  if (a === 'favorites') return allItems((t) => list(t, { favorite: 1 }));
  if (a === 'review' && !b) {
    const due = allItems((t) => db.prepare(`SELECT * FROM ${t} WHERE review_flag=1 AND (next_review IS NULL OR next_review<=?)`).all(now()));
    const history = db.prepare('SELECT * FROM review_history ORDER BY reviewed_at DESC LIMIT 30').all();
    return { due, history };
  }
  if (a === 'calendar') return activityByDay(q.month || now().slice(0, 7));
  if (a === 'day') return allItems((t) => db.prepare(`SELECT * FROM ${t} WHERE created_at LIKE ?`).all(`${q.date}%`));
  if (a === 'export') return exportAll();
  if (a === 'import' && m === 'POST') return importAll(body);
  if (a === 'settings') {
    if (m === 'PUT') for (const [k, v] of Object.entries(body)) db.prepare('INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v));
    return Object.fromEntries(db.prepare("SELECT * FROM settings WHERE key!='seeded'").all().map((r) => [r.key, r.value]));
  }
  if (a === 'categories') {
    if (m === 'GET') return db.prepare('SELECT * FROM categories ORDER BY id').all();
    if (m === 'POST') { try { return db.prepare('INSERT INTO categories (name,color) VALUES (?,?)').run(body.name, body.color || '#C98F9B'), { ok: true }; } catch { throw new HttpError(400, 'Nome inválido ou já existente'); } }
    if (m === 'DELETE') return db.prepare('DELETE FROM categories WHERE id=?').run(b), { ok: true };
  }
  const t = table(a);
  if (!b) return m === 'GET' ? list(t, q) : create(t, body);
  if (c === 'favorite') { db.prepare(`UPDATE ${t} SET favorite=1-favorite WHERE id=?`).run(b); return db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(b); }
  if (c === 'review') return review(t, b, body);
  if (m === 'GET') { const r = db.prepare(`SELECT * FROM ${t} WHERE id=?`).get(b); if (!r) throw new HttpError(404, 'Não encontrado'); return r; }
  if (m === 'PUT') return update(t, b, body);
  if (m === 'DELETE') { db.transaction(() => { db.prepare(`DELETE FROM ${t} WHERE id=?`).run(b); db.prepare('DELETE FROM review_history WHERE item_type=? AND item_id=?').run(t, b); })(); return { ok: true }; }
  throw new HttpError(405, 'Método não permitido');
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) {
      let raw = ''; for await (const ch of req) raw += ch;
      const out = await route(req, url, raw ? JSON.parse(raw) : {});
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify(out));
    }
    const file = path.join(ROOT, 'public', url.pathname === '/' ? 'index.html' : url.pathname);
    if (!file.startsWith(path.join(ROOT, 'public')) || !fs.existsSync(file)) { res.writeHead(404); return res.end('Não encontrado'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' }); res.end(fs.readFileSync(file));
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e); // detalhes internos ficam só no log
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ error: status === 500 ? 'Erro interno' : e.message }));
  }
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, '127.0.0.1', () => console.log(`Japanese Journal em http://localhost:${PORT}`));
