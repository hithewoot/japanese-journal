# Japanese Journal (v0.1)
Caderno digital de estudos de japonês. Node.js + SQLite (better-sqlite3), frontend em HTML/CSS/JS puro. Funciona 100% local.

## Executar (Linux/macOS/Windows)
Requisitos: Node.js 18+.
    npm install
    npm run init-db     # cria/atualiza o banco (nunca sobrescreve dados existentes)
    npm start           # http://localhost:3000
    npm test            # testes (banco, japonês, revisão espaçada)

## Backup / restauração
    npm run backup      # cria backups/japanese_journal-DATA.db
Restaurar: pare o servidor e copie o backup sobre `database/japanese_journal.db`.
Em Configurações você também exporta/importa JSON (a importação faz backup automático antes).

## Estrutura
- `server.js` API REST + estáticos · `src/db.js` conexão e migrações · `src/srs.js` intervalos de revisão
- `database/` schema, seed, migrations (nova mudança = nova migração `002_...sql`)
- `public/` interface (`style.css` tem as variáveis de cores/fontes)

## Personalizar
- Cores/fontes: variáveis no topo de `public/style.css` (ou Configurações).
- Categorias: em Configurações.
- Intervalos de revisão: `INTERVALS_DAYS` em `src/srs.js`.
- Nova área: migração + `CONTENT` em `server.js` + `TYPES` em `public/app.js`.
- Remover exemplos: `DELETE FROM vocabulary WHERE tags LIKE '%demo%';` (idem grammar).
