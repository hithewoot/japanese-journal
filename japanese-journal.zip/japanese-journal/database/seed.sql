-- Dados iniciais. Roda UMA vez (controlado por settings.seeded).
-- Para remover os exemplos: DELETE FROM vocabulary WHERE tags LIKE '%demo%'; (idem notes/grammar)
INSERT OR IGNORE INTO categories(name,color) VALUES
('Hiragana','#C98F9B'),('Katakana','#B5838D'),('Kanji','#C0504D'),('Vocabulário','#8FA998'),('Gramática','#7F95A8'),
('Partículas','#A78FB5'),('Verbos','#8FA998'),('Adjetivos','#C9A58F'),('Expressões do cotidiano','#C98F9B'),
('Frases e exemplos','#7F95A8'),('Escuta e pronúncia','#A8A08F'),('Cultura japonesa','#C0504D'),('Dúvidas','#A78FB5'),('Anotações gerais','#A8A08F');
INSERT INTO vocabulary(word,reading,romaji,meaning,part_of_speech,example,example_translation,notes,tags,created_at,updated_at)
VALUES('食べる','たべる','taberu','comer','verbo','毎日パンを食べます。','Como pão todos os dias.','Forma polida: 食べます','demo',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now'));
INSERT INTO grammar(title,explanation,formation,examples,tags,created_at,updated_at)
VALUES('〜たい — querer fazer algo','Expressa desejo do falante.','Verbo (raiz) + たい','水が飲みたいです。','demo',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now'));
