// Acesso ao SQLite. Só o backend importa este arquivo; o frontend usa a API.
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DB_PATH = process.env.DB_PATH || path.join(ROOT, 'database', 'japanese_journal.db');

// Abre (ou cria) o banco, liga chaves estrangeiras e aplica migrações pendentes.
// Nunca sobrescreve um banco existente.
export function openDb(dbPath = DB_PATH) {
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  migrate(db);
  return db;
}

// Migrações: arquivos database/migrations/NNN_nome.sql, aplicados em ordem, uma vez cada.
// Para mudar o esquema, crie 002_algo.sql — nunca edite uma migração já aplicada.
function migrate(db) {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  const dir = path.join(ROOT, 'database', 'migrations');
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort()) {
    if (db.prepare('SELECT 1 FROM schema_migrations WHERE name=?').get(file)) continue;
    db.transaction(() => {
      db.exec(fs.readFileSync(path.join(dir, file), 'utf8'));
      db.prepare('INSERT INTO schema_migrations VALUES (?,?)').run(file, new Date().toISOString());
    })();
  }
  if (!db.prepare("SELECT 1 FROM settings WHERE key='seeded'").get()) {
    db.transaction(() => {
      db.exec(fs.readFileSync(path.join(ROOT, 'database', 'seed.sql'), 'utf8'));
      db.prepare("INSERT INTO settings VALUES ('seeded','1')").run();
    })();
  }
}
