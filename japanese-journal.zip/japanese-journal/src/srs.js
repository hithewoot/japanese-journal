// Revisão espaçada. Para ajustar a frequência, edite só INTERVALS_DAYS.
export const INTERVALS_DAYS = [1, 3, 7, 14, 30, 60, 120];
export const RESULTS = ['unknown', 'learning', 'known']; // Ainda não sei / Estou aprendendo / Já sei

// "unknown" volta ao início; "learning" repete o intervalo; "known" avança um degrau.
export function nextStep(step, result) {
  if (result === 'unknown') return 0;
  if (result === 'learning') return step;
  if (result === 'known') return Math.min(step + 1, INTERVALS_DAYS.length - 1);
  throw new Error('Resultado de revisão inválido');
}
export function calculateNextReview(from, step) {
  const d = new Date(from);
  d.setUTCDate(d.getUTCDate() + INTERVALS_DAYS[step]);
  return d.toISOString();
}
